from pathlib import Path


DATA_ROOT = Path('/content/working')
