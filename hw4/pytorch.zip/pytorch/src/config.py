from pathlib import Path


DATA_ROOT = Path('replace_with_your_directory_path')
